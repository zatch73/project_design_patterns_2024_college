<?php

use app\router\Router;

$router = new Router();
//API 
$router->add('GET', '/mangas', 'MangaController@retornar_todos_mangas', true);
$router->add('POST', '/mangas', 'MangaController@cadastrar_manga', true);
$router->add('GET', '/mangas/{id}', 'MangaController@retornar_manga_por_id', true);
$router->add('DELETE', '/mangas/{id}', 'MangaController@deletar_manga', true);
$router->add('PUT', '/mangas/{id}', 'MangaController@atualizar_manga', true);

$router->add('GET', '/usuarios', 'UsuarioController@retornar_todos_usuarios', true);
$router->add('POST', '/usuarios', 'UsuarioController@cadastrar_usuario', true);
$router->add('DELETE', '/usuarios/{id}', 'UsuarioController@deletar_usuario', true);
$router->add('PUT', '/usuarios/{id}', 'UsuarioController@alterar_usuario', true);
$router->add('POST', '/login', 'UsuarioController@login_usuario_email', true);

//TELAS
$router->add('GET', '/', 'MangaController@tela_home', false);
$router->add('GET', '/sair', 'UsuarioController@sair', false);
$router->add('GET', '/tela/mangas', 'MangaController@tela_mangas', false);
$router->add('GET', '/tela/login', 'UsuarioController@tela_login_usuario', false);
$router->add('GET', '/tela/cadastro', 'UsuarioController@tela_cadastro_usuario', false);
$router->add('GET', '/tela/admin', 'UsuarioController@tela_admin_padrao', false);
$router->add('GET', '/tela/admin/mangas', 'MangaController@tela_mangas_admin', false);
$router->add('GET', '/tela/admin/usuarios', 'UsuarioController@tela_usuarios', false);

if (!$router->match($_SERVER['REQUEST_METHOD'], $_SERVER['REQUEST_URI'])) {
    echo '<h1>PAGE NOT FOUND</h1>';
    echo '<a href="/"> retornar para home</a>';
}