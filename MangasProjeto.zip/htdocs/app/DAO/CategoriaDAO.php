<?php

namespace app\DAO;
use app\models\CategorialModel;

class CategoriaDAO {
    private $db;
    public function __construct($db)
    {
        $this->db = $db;
    }
    public function retornar_categoria_por_id($id){
        $query = " SELECT *
        FROM categoria 
        WHERE categoria.id = :id";
        $result = $this->db->prepare($query);
        $result->bindParam(':id', $id, \PDO::PARAM_INT);
        $result->execute();
        $obj = '';
        if ($result->rowCount() > 0) {
            foreach ($result->fetchAll(\PDO::FETCH_OBJ) as $key => $obResult) {
                $obj = new CategorialModel();
                $obj->setId($obResult->id);
                $obj->setCategoria($obResult->categoria);
                $obj->setDescricao($obResult->descricao);
                $obj = $obj->montarArray();
            }
        }
        return $obj;
    }
}