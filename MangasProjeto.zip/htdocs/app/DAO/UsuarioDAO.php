<?php

namespace app\DAO;

use app\models\UsuarioModel;

class UsuarioDAO
{

    private $db;
    public function __construct($db)
    {
        $this->db = $db;
    }
    public function retornar_todos_usuarios()
    {
        $list = array();
        $query = $query = " SELECT id, usuario, email, ser_administrador, saldo FROM usuario";
        $result = $this->db->prepare($query);
        $result->execute();

        if ($result->rowCount() > 0) {
            foreach ($result->fetchAll(\PDO::FETCH_OBJ) as $key => $obResult) {
                $obj = new UsuarioModel();
                $obj->setId($obResult->id);
                $obj->setUsuario($obResult->usuario);
                $obj->setEmail($obResult->email);
                $obj->setSerAdmin((bool) $obResult->ser_administrador);
                $obj->setSaldo($obResult->saldo);
                array_push($list, $obj->montarArray());
            }
        }
        return $list;
    }
    public function login_com_email($usuario){
        $email = $usuario->getEmail();
        $query = "SELECT * FROM usuario WHERE email = :email";
        $result = $this->db->prepare($query);
        $result->bindParam(':email', $email);
        $result->execute();
        $obj = null;
        if ($result->rowCount() > 0) {
            foreach ($result->fetchAll(\PDO::FETCH_OBJ) as $key => $obResult) {
                $obj = new UsuarioModel();
                $obj->setId($obResult->id); 
                $obj->setUsuario($obResult->usuario);
                $obj->setEmail($obResult->email);
                $obj->setSenha($obResult->senha);
                $obj->setSerAdmin((bool) $obResult->ser_administrador);
                $obj->setSaldo($obResult->saldo);
            }
        }
        return $obj;
    }
    public function deletar_usuario($id){
        $query = "DELETE FROM usuario WHERE id = :id";
        $result = $this->db->prepare($query);
        $result->bindParam(':id', $id, \PDO::PARAM_INT);
        $result->execute();
        return $result->rowCount() > 0;
    }
    public function cadastrar_usuario($usuario){
        $query = "INSERT INTO usuario 
        (usuario, email, senha, ser_administrador) 
        VALUES 
        (:usuario, :email, :senha, :ser_administrador)";
      $result = $this->db->prepare($query);
      $params = [
          ':usuario' => $usuario->getUsuario(),
          ':email' => $usuario->getEmail(),
          ':senha' => $usuario->getSenha(),
          ':ser_administrador' => $usuario->getSerAdmin(),
      ];
      $result->execute($params);
      $usuario->setId($this->db->lastInsertId());
      return $usuario;
    }

    public function atualizar_usuario($usuario)
    {
        $query = "UPDATE usuario SET 
                  usuario = :usuario, 
                  email = :email, 
                  senha = :senha,
                  saldo = :saldo,
                  ser_administrador = :ser_administrador
                  WHERE id = :id";

        $result = $this->db->prepare($query);
        $params = [
            ':usuario' => $usuario->getUsuario(),
            ':email' => $usuario->getEmail(),
            ':senha' => $usuario->getSenha(),
            ':saldo' => $usuario->getSaldo(),
            ':ser_administrador' => (bool) $usuario->getSerAdmin(),
            ':id' => (int)$usuario->getId()
        ];
        $result->execute($params);
        return $usuario;
    }
}
