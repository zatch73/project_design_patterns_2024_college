<?php
namespace app\controllers;

use app\controllers\BaseController;


class AssetController extends BaseController
{
    public function carregar($tipo, $caminho)
    {
        $tipoCaminho = '';
        switch ($tipo) {
            case "js":
                $tipoCaminho = '/js/';
                break;
            case 'css':
                $tipoCaminho = '/css/';
                break;
            case 'images':
                $tipoCaminho = '/images/';
                break;
        }
        //header('Content-Type: text/javascript');
        return file_get_contents('./'.substr($caminho, strpos($caminho, $tipoCaminho)));
       
    }
}