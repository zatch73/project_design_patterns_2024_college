<?php

namespace app\controllers;

use app\controllers\BaseController;
use app\DAO\MangaDAO;
use app\models\factories\MangaFactory;
use app\models\MangaModel;

class MangaController extends BaseController
{
    private function msgSemPermisao(){
        return ['status' => 'sem permissao'];
    }
    public function retornar_todos_mangas()
    {
        if($this->validaSessao()){
            $mangaDAO = new MangaDAO($this->getConexao());
            return $mangaDAO->retornar_todos_mangas();
        }
        return $this->msgSemPermisao();
    }

    public function retornar_manga_por_id($id)
    {
        $mangaDAO = new MangaDAO($this->getConexao());
        return $mangaDAO->retornar_manga_por_id($id);
    }
    public function cadastrar_manga()
    {
        $body = json_decode(file_get_contents('php://input'), true);

        $manga = new MangaFactory();
        $manga = $manga->criarManga($body['categoria']);
        $manga->setTitulo($body['titulo'] ?? null);
        $manga->setAutor($body['autor'] ?? null);
        $manga->setGenero($body['genero'] ?? null);
        $manga->setAnoPublicacao($body['ano_publicacao'] ?? null);
        $manga->setDescricao($body['descricao'] ?? null);
        $manga->setPreco($body['preco'] ?? null);
        $manga->setQuantidadeEmEstoque($body['quantidade_em_estoque'] ?? null);
        $manga->setEditora($body['editora'] ?? null);

        $mangaDAO = new MangaDAO($this->getConexao());
        return $mangaDAO->cadastrar_manga($manga);

    }
    public function atualizar_manga($id)
    {
        $body = json_decode(file_get_contents('php://input'), true);
        $manga = new MangaFactory();
        $manga = $manga->criarManga($body['categoria']);
        var_dump($manga);
        $manga->setId($id);
        $manga->setTitulo($body['titulo'] ?? null);
        $manga->setAutor($body['autor'] ?? null);
        $manga->setGenero($body['genero'] ?? null);
        $manga->setAnoPublicacao($body['ano_publicacao'] ?? null);
        $manga->setDescricao($body['descricao'] ?? null);
        $manga->setPreco($body['preco'] ?? null);
        $manga->setQuantidadeEmEstoque($body['quantidade_em_estoque'] ?? null);
        $manga->setEditora($body['editora'] ?? null);

        $mangaDAO = new MangaDAO($this->getConexao());
        return $mangaDAO->atualizar_manga($id, $manga);
    }
    public function deletar_manga($id)
    {
        $mangaDAO = new MangaDAO($this->getConexao());
        return $mangaDAO->deletar_manga($id);
    }
    public function tela_home()
    {
        if ($this->validaSessao()) {
            $this->renderizar_tela(('tela_home'));
        } else {
            $this->renderizar_tela('tela_login_usuario');
        }
    }
    public function tela_mangas()
    {
        if ($this->validaSessao()) {
            $this->renderizar_tela(('tela_mangas'));
        } else {
            header('Location: /');
        }
    }
    public function tela_mangas_admin()
    {
        if ($this->validaSessao()) {
            if($this->validaSerAdmin()){
                $this->renderizar_tela(('admin/tela_admin_mangas'));
            }else {
                echo "<a href='/'>SEM PERMISSAO</a>";
            }
        } else {
            header('Location: /');
        }
    }

    private function validaSessao(){
        session_start();
        return $_SESSION['logado'] ?? false;
    }
    private function validaSerAdmin(){
        return $_SESSION['admin'] = true;
    }
}
