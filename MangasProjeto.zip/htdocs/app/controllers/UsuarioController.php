<?php

namespace app\controllers;

use app\controllers\BaseController;
use app\DAO\UsuarioDAO;
use app\models\UsuarioModel;

class UsuarioController extends BaseController
{
    public function retornar_todos_usuarios()
    {
        $usuarioDAO = new UsuarioDAO($this->getConexao());
        return $usuarioDAO->retornar_todos_usuarios();
    }
    public function login_usuario_email()
    {
        $body = json_decode(file_get_contents('php://input'), true);
        $usuario = new UsuarioModel();
        $usuario->setEmail($body['email']);
        $usuarioDAO = new UsuarioDAO($this->getConexao());
        $usuario = $usuarioDAO->login_com_email($usuario);
        
        if (password_verify($body['senha'], $usuario->getSenha())) {
            session_start();
            $_SESSION['logado'] = true;
            $_SESSION['admin'] = $usuario->getSerAdmin();
            $_SESSION['usuario'] = $usuario->getUsuario();
            $_SESSION['saldo'] = $usuario->getSaldo();
            return ['status' => 'logado com sucesso'];
        } else {
            return ['status' => 'senha errada'];
        }
    }
    public function sair()
    {
        session_start();
        $_SESSION = array();
        session_destroy();
        $this->renderizar_tela('tela_login_usuario');
    }
    public function deletar_usuario($id)
    {
        $usuarioDAO = new UsuarioDAO($this->getConexao());
        return $usuarioDAO->deletar_usuario($id);
    }
    public function tela_home()
    {
        $this->renderizar_tela(('tela_home'));
    }
    public function tela_usuario()
    {
        $this->renderizar_tela(('tela_usuario'));
    }
    public function tela_usuarios()
    {
        $this->renderizar_tela(('admin/tela_admin_usuarios'));
    }
    public function tela_admin_padrao()
    {
        session_start();
        if($_SESSION['admin']){
            $this->renderizar_tela(('admin/tela_admin_padrao'));
        }else {
            header('Location: /');
        }
    }
    
    public function cadastrar_usuario(){
        $body = json_decode(file_get_contents('php://input'), true);

        $usuario = new UsuarioModel();
        $usuario->setUsuario($body['usuario'] ?? null);
        $usuario->setEmail($body['email'] ?? null);
        $usuario->setSenha(password_hash(($body['senha'] ?? null), PASSWORD_DEFAULT));
        $usuario->setSerAdmin($body['admin'] ?? null);

        $usuarioDAO = new UsuarioDAO($this->getConexao());
        return $usuarioDAO->cadastrar_usuario($usuario);
    }
    public function alterar_usuario($id){
        $body = json_decode(file_get_contents('php://input'), true);

        $usuario = new UsuarioModel();

        $usuario->setId($id);
        $usuario->setUsuario($body['usuario'] ?? null);
        $usuario->setEmail($body['email'] ?? null);
        $usuario->setSenha(password_hash(($body['senha'] ?? null), PASSWORD_DEFAULT));
        $usuario->setSerAdmin($body['admin'] ?? null);
        $usuario->setSaldo((float)($body['saldo'] ?? null));

        $usuarioDAO = new UsuarioDAO($this->getConexao());
        return $usuarioDAO->atualizar_usuario($usuario);
    }
}

