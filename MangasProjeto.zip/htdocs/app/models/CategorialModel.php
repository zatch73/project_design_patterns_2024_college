<?php

namespace app\models;

class CategorialModel implements Model {
    private $id;
    private $categoria;
    private $descricao;

    public function __construct($id = null, $categoria = null, $descricao = null) {
        $this->id = $id;
        $this->categoria = $categoria;
        $this->descricao = $descricao;
    }

    public function getId() {
        return $this->id;
    }

    public function getCategoria() {
        return $this->categoria;
    }
    public function getDescricao() {
        return $this->descricao;
    }

    public function setId($value) {
        $this->id = $value;
    }

    public function setCategoria($value) {
        $this->categoria = $value;
    }
    public function setDescricao($value) {
        $this->descricao = $value;
    }    
    
    public function montarArray() {
        return [
            'id' => $this->id,
            'categoria' => $this->categoria,
            'descricao' => $this->descricao
        ];
    }
}