<?php

namespace app\models\mangas;
use app\models\MangaModel;

class ShonenMangaModel extends MangaModel{
    public function __construct()
    {
        parent::__construct('1');
    }
}