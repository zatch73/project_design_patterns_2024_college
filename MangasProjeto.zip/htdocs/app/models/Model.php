<?php
namespace app\models;
interface Model{
    public function montarArray();
}