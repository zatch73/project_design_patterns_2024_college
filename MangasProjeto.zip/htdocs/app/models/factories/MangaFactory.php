<?php
namespace app\models\factories;
use app\models\mangas\JoseiMangaModel;
use app\models\mangas\SeinenMangaModel;
use app\models\mangas\ShojoMangaModel;
use app\models\mangas\ShonenMangaModel;
class MangaFactory {
    public function criarManga($tipo){
        switch ($tipo) {
            case 'Seinen':
                return new SeinenMangaModel();
            case 'Josei':
                return new JoseiMangaModel();
            case 'Shojo':
                return new ShojoMangaModel();
            case 'Shonen':
                return new ShonenMangaModel();
        }
    }
}