<?php

namespace app\models;

class UsuarioModel implements Model
{
    private $id;
    private $usuario;
    private $email;
    private $senha;
    private $serAdmin;
    private $saldo;

    public function __construct($id = null, $usuario = null, $email = null, $senha = null, $serAdmin = null, $saldo = null)
    {
        $this->id = $id;
        $this->usuario = $usuario;
        $this->email = $email;
        $this->senha = $senha;
        $this->serAdmin = $serAdmin;
        $this->saldo = $saldo;
    }

    public function getId()
    {
        return $this->id;
    }

    public function getUsuario()
    {
        return $this->usuario;
    }

    public function getEmail()
    {
        return $this->email;
    }

    public function getSenha()
    {
        return $this->senha;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function setUsuario($usuario)
    {
        $this->usuario = $usuario;
    }

    public function setEmail($email)
    {
        $this->email = $email;
    }

    public function setSenha($senha)
    {
        $this->senha = $senha;
    }

    public function getSerAdmin()
    {
        return $this->serAdmin;
    }
    public function setSerAdmin($serAdmin)
    {
        $this->serAdmin = $serAdmin;
    }
    public function setSaldo($saldo)
    {
        $this->saldo = $saldo;
    }
    public function getSaldo()
    {
        return $this->saldo;
    }

    public function montarArray() {
        return [
            'id' => $this->id,
            'usuario' => $this->usuario,
            'email' => $this->email,
            'senha' => $this->senha,
            'serAdmin' => $this->serAdmin,
            'saldo' => $this->saldo
        ];
    }
}
