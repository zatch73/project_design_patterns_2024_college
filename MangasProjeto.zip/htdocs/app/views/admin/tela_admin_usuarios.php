<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <title></title>

    <?php
    include_once (__DIR__ . '\..\css\bootstrap.php');
    ?>

</head>

<body>

    <?php
    include_once (__DIR__ . '\..\components\menu.php');
    ?>
    <div class="container">
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#insert">
            Novo
        </button>
    </div>
    <div class="modal fade" id="insert" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Caixa sistema</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="insert_box_usuario" class="form-label">usuario</label>
                        <input type="text" class="form-control" id="insert_box_usuario">
                    </div>
                    <div class="mb-3">
                        <label for="insert_box_email" class="form-label">email</label>
                        <input type="text" class="form-control" id="insert_box_email">
                    </div>
                    <div class="mb-3">
                        <label for="insert_box_senha" class="form-label">senha</label>
                        <input type="text" class="form-control" id="insert_box_senha">
                    </div>
                    <div class="mb-3">
                        <label for="insert_box_ser_adm" class="form-label">Ser admin</label>
                        <input class="form-check-input" type="checkbox" id="insert_box_ser_adm">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Sair</button>
                    <button type="button" class="btn btn-primary" onclick="inserir()">Executar</button>
                </div>
            </div>
        </div>
    </div>
    <table class="table container">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Usuario</th>
                <th scope="col">Email</th>
                <th scope="col">Saldo</th>
                <th scope="col">ADM</th>
                <th scope="col">Acoes</th>
            </tr>
        </thead>
        <tbody id="mangas_box">

        </tbody>
    </table>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Caixa sistema</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="update_box_usuario" class="form-label">id</label>
                        <input type="text" class="form-control" id="update_box_id" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="update_box_usuario" class="form-label">usuario</label>
                        <input type="text" class="form-control" id="update_box_usuario">
                    </div>
                    <div class="mb-3">
                        <label for="update_box_email" class="form-label">email</label>
                        <input type="text" class="form-control" id="update_box_email">
                    </div>
                    <div class="mb-3">
                        <label for="update_box_senha" class="form-label">senha</label>
                        <input type="text" class="form-control" id="update_box_senha">
                    </div>
                    <div class="mb-3">
                        <label for="update_box_senha" class="form-label">saldo</label>
                        <input type="number" class="form-control" id="update_box_saldo">
                    </div>
                    <div class="mb-3">
                        <label for="update_box_ser_adm" class="form-label">Ser admin</label>
                        <input class="form-check-input" type="checkbox" id="update_box_ser_adm">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Sair</button>
                    <button type="button" class="btn btn-primary" onclick="alterar()">Executar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="./js/http.js"></script>
    <script>
        const httpClient = new HttpClient();
        let mangas = null;
        var resultado = httpClient.get('http://localhost/usuarios').then((data) => {
            mangas = data;
            let lista_de_mangas = "";
            for (let i = 0; i < data.length; i++) {
                let manga = criarEstruturaManga(mangas[i]);
                lista_de_mangas += manga;
            }
            const mangasBox = document.getElementById('mangas_box');
            mangasBox.innerHTML = lista_de_mangas;

        })

        function criarEstruturaManga(manga) {
            return `<tr>
      <th>${manga.id}</th>
      <td>${manga.usuario}</td>
      <td>${manga.email}</td>
      <td>${manga.saldo}</td>
      <td>${manga.serAdmin}</td>
      <td>
        <button class='btn btn-success' onclick='setar(${manga.id}, "${manga.usuario}", "${manga.email}" , "${manga.saldo}",${manga.serAdmin})' data-bs-toggle="modal" data-bs-target="#exampleModal">
        <i class='fas fa-times'></i>
        </button>
        <button class='btn btn-danger' onclick='deletar(${manga.id})'>
          <i class='fas fa-times'></i>
        </button>
        </td>
      </tr>`;
        }
        function inserir() {
            const usuario = document.getElementById('insert_box_usuario').value;
            const senha = document.getElementById('insert_box_senha').value;
            const email = document.getElementById('insert_box_email').value;
            const admin = document.getElementById('insert_box_ser_adm').checked;

            const body = {
                usuario: usuario,
                senha: senha,
                email: email,
                admin: admin,
            };

            httpClient.post('http://localhost/usuarios', body).then(data => {
                console.log(data);
            });
            alert('cadastrado')
            window.location = "http://localhost/tela/admin/usuarios";
        }
        function alterar() {
            const id = document.getElementById('update_box_id').value;
            const usuario = document.getElementById('update_box_usuario').value;
            const senha = document.getElementById('update_box_senha').value;
            const saldo = document.getElementById('update_box_saldo').value;
            const email = document.getElementById('update_box_email').value;
            const admin = document.getElementById('update_box_ser_adm').checked;

            const body = {
                usuario: usuario,
                senha: senha,
                email: email,
                admin: admin,
                saldo: saldo
            };

            httpClient.put('http://localhost/usuarios/'+id, body).then(data => {
                console.log(data);
            });
            alert('alterado')
            window.location = "http://localhost/tela/admin/usuarios";
        }
        function deletar(id) {
            if(confirm('DESEJA DELETAR')){
                var resultado = httpClient.delete('http://localhost/usuarios/' + id);
                alert('deletou manga ' + id)
                window.location = "http://localhost/tela/admin/usuarios";
            }
        }
        function setar(id, usuario, email, saldo, admin) {
            document.getElementById('update_box_id').value = id;
            document.getElementById('update_box_usuario').value = usuario;
            document.getElementById('update_box_email').value = email;
            document.getElementById('update_box_saldo').value = saldo;
            document.getElementById('update_box_ser_adm').checked = admin;
            //aler(usuario);
        }
    </script>

    <?php
    include_once (__DIR__ . '\..\scripts\bootstrap.php');
    ?>

</body>

</html>