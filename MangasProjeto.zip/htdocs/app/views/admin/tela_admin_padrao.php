<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <?php
    include_once(__DIR__ . '\..\css\bootstrap.php');
    ?>
</head>

<body>
    <?php
    include_once(__DIR__ . '\..\components\menu.php');
    ?>

    <div class="container text-center">
        <a href="/tela/admin/usuarios" class="btn btn-secondary">Usuarios</a>
        <a href="/tela/admin/mangas" class="btn btn-success">Mangas</a>
        <a href="" class="btn btn-danger">Vendas</a>
    </div>
    </div>
    <?php
    include_once(__DIR__ . '\..\scripts\bootstrap.php');
    ?>
</body>

</html>