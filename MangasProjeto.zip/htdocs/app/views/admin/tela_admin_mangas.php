<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <title></title>

    <?php
    include_once (__DIR__ . '\..\css\bootstrap.php');
    ?>

</head>

<body>

    <?php
    include_once (__DIR__ . '\..\components\menu.php');
    ?>
    <div class="container">
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#insert">
            Novo
        </button>
    </div>
    <div class="modal fade" id="insert" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Caixa sistema</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="insert_box_titulo" class="form-label">titulo</label>
                        <input type="text" class="form-control" id="insert_box_titulo">
                    </div>
                    <div class="mb-3">
                        <label for="insert_box_autor" class="form-label">autor</label>
                        <input type="text" class="form-control" id="insert_box_autor">
                    </div>
                    <div class="mb-3">
                        <label for="insert_box_genero" class="form-label">genero</label>
                        <input type="text" class="form-control" id="insert_box_genero">
                    </div>
                    <div class="mb-3">
                        <label for="insert_box_ano_publicacao" class="form-label">ano_publicacao</label>
                        <input type="text" class="form-control" id="insert_box_ano_publicacao">
                    </div>
                    <div class="mb-3">
                        <label for="insert_box_descricao" class="form-label">descricao</label>
                        <input type="text" class="form-control" id="insert_box_descricao">
                    </div>
                    <div class="mb-3">
                        <label for="insert_box_preco" class="form-label">preco</label>
                        <input type="text" class="form-control" id="insert_box_preco">
                    </div>
                    <div class="mb-3">
                        <label for="insert_box_quantidade_em_estoque" class="form-label">quantidade_em_estoque</label>
                        <input type="text" class="form-control" id="insert_box_quantidade_em_estoque">
                    </div>
                    <div class="mb-3">
                        <label for="insert_box_editora" class="form-label">editora</label>
                        <input type="text" class="form-control" id="insert_box_editora">
                    </div>
                    <div class="mb-3" id="insert_escolhas_categoria">
                        <select id="insert_box_categoria" name="fruits">
                            <option value="1">Shonen</option>
                            <option value="2">Shojo</option>
                            <option value="3">Seinen</option>
                            <option value="4">Josei</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Sair</button>
                    <button type="button" class="btn btn-primary" onclick="inserir()">Executar</button>
                </div>
            </div>
        </div>
    </div>
    <table class="table container">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Titulo</th>
                <th scope="col">Autor</th>
                <th scope="col">Genero</th>
                <th scope="col">Ano Publicacao</th>
                <th scope="col">Descricao</th>
                <th scope="col">Preco</th>
                <th scope="col">Quantidades</th>
                <th scope="col">Editora</th>
                <th scope="col">Categoria</th>
                <th scope="col">Acoes</th>
            </tr>
        </thead>
        <tbody id="mangas_box">

        </tbody>
    </table>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Caixa sistema</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="box_id" class="form-label">ID</label>
                        <input type="text" class="form-control" id="box_id" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="box_titulo" class="form-label">titulo</label>
                        <input type="text" class="form-control" id="box_titulo">
                    </div>
                    <div class="mb-3">
                        <label for="box_autor" class="form-label">autor</label>
                        <input type="text" class="form-control" id="box_autor">
                    </div>
                    <div class="mb-3">
                        <label for="box_genero" class="form-label">genero</label>
                        <input type="text" class="form-control" id="box_genero">
                    </div>
                    <div class="mb-3">
                        <label for="box_ano_publicacao" class="form-label">ano_publicacao</label>
                        <input type="text" class="form-control" id="box_ano_publicacao">
                    </div>
                    <div class="mb-3">
                        <label for="box_descricao" class="form-label">descricao</label>
                        <input type="text" class="form-control" id="box_descricao">
                    </div>
                    <div class="mb-3">
                        <label for="box_preco" class="form-label">preco</label>
                        <input type="text" class="form-control" id="box_preco">
                    </div>
                    <div class="mb-3">
                        <label for="box_quantidade_em_estoque" class="form-label">quantidade_em_estoque</label>
                        <input type="text" class="form-control" id="box_quantidade_em_estoque">
                    </div>
                    <div class="mb-3">
                        <label for="box_editora" class="form-label">editora</label>
                        <input type="text" class="form-control" id="box_editora">
                    </div>
                    <div class="mb-3" id="escolhas_categoria">
                        <select id="box_categoria" name="fruits">
                            <option value="1">Shonen</option>
                            <option value="2">Shojo</option>
                            <option value="3">Seinen</option>
                            <option value="4">Josei</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Sair</button>
                    <button type="button" class="btn btn-primary" onclick="alterar()">Executar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="./js/http.js"></script>
    <script>
        const httpClient = new HttpClient();
        let mangas = null;
        var resultado = httpClient.get('http://localhost/mangas').then((data) => {
            mangas = data;
            let lista_de_mangas = "";
            for (let i = 0; i < data.length; i++) {
                let manga = criarEstruturaManga(mangas[i]);
                lista_de_mangas += manga;
            }
            const mangasBox = document.getElementById('mangas_box');
            mangasBox.innerHTML = lista_de_mangas;

        })

        function criarEstruturaManga(manga) {
            return `<tr>
      <th>${manga.id}</th>
      <td>${manga.titulo}</td>
      <td>${manga.autor}</td>
      <td>${manga.genero}</td>
      <td>${manga.ano_publicacao}</td>
      <td>${manga.descricao}</td>
      <td>${manga.preco}</td>
      <td>${manga.quantidade_em_estoque}</td>
      <td>${manga.editora}</td>
      <td>${manga.categoria.categoria}</td>
      <td>
        <button class='btn btn-success' onclick='setar(${manga.id}, "${manga.titulo}", "${manga.autor}" , "${manga.genero}",${manga.ano_publicacao}, "${manga.descricao}",${manga.preco}, ${manga.quantidade_em_estoque}, "${manga.editora}", "${manga.categoria}")' data-bs-toggle="modal" data-bs-target="#exampleModal">
        <i class='fas fa-times'></i>
        </button>
        <button class='btn btn-danger' onclick='deletar(${manga.id})'>
          <i class='fas fa-times'></i>
        </button>
        </td>
      </tr>`;
        }
        function inserir() {
            const titulo = document.getElementById('insert_box_titulo').value;
            const autor = document.getElementById('insert_box_autor').value;
            const genero = document.getElementById('insert_box_genero').value;
            const ano_publicacao = document.getElementById('insert_box_ano_publicacao').value;
            const descricao = document.getElementById('insert_box_descricao').value;
            const preco = document.getElementById('insert_box_preco').value;
            const quantidade_em_estoque = document.getElementById('insert_box_quantidade_em_estoque').value;
            const editora = document.getElementById('insert_box_editora').value;
            let categoria = document.getElementById('insert_box_categoria').value;
            if (categoria == "1") {
                categoria = "Shonen"
            }
            if (categoria == "2") {

                categoria = "Shojo"
            }
            if (categoria == "3") {

                categoria = "Seinen"
            }
            if (categoria == "4") {
                categoria = "Josei"
            }
            httpClient.post('http://localhost/mangas', {
                titulo: titulo,
                autor: autor,
                genero: genero,
                ano_publicacao: ano_publicacao,
                descricao: descricao,
                preco: preco,
                quantidade_em_estoque: quantidade_em_estoque,
                editora: editora,
                categoria: categoria,
            }).then(data => {
                console.log(data);
            });
            alert('cadastrado')
            window.location = "http://localhost/tela/admin/mangas";
        }
        function deletar(id) {
            var resultado = httpClient.delete('http://localhost/mangas/' + id);
            alert('deletou manga ' + id)
            window.location = "http://localhost/tela/admin/mangas";
        }
        function setar(id, titulo, autor, genero, ano_publicacao, descricao, preco, quantidade_em_estoque, editora, categoria) {
            document.getElementById('box_id').value = id;
            document.getElementById('box_titulo').value = titulo;
            document.getElementById('box_autor').value = autor;
            document.getElementById('box_genero').value = genero;
            document.getElementById('box_ano_publicacao').value = ano_publicacao;
            document.getElementById('box_descricao').value = descricao;
            document.getElementById('box_preco').value = preco;
            document.getElementById('box_quantidade_em_estoque').value = quantidade_em_estoque;
            document.getElementById('box_editora').value = editora;
            let lugar = document.getElementById('escolhas_categoria');
            if (categoria.id == 1) {
                lugar.innerHTML +=
                    "<select id = 'box_categoria' name = 'fruits'>"
                lugar.innerHTML += "<option value='1' selected>Shonen</option>"
                lugar.innerHTML += "<option value='2'>Shojo</option>"
                lugar.innerHTML += "<option value='3'>Seinen</option>"
                lugar.innerHTML += "<option value='4'>Josei</option></ >"
            }
            if (categoria.id == 2) {
                lugar.innerHTML +=
                    "<select id = 'box_categoria' name = 'fruits'>"
                lugar.innerHTML += "<option value='1'>Shonen</option>"
                lugar.innerHTML += "<option value='2' selected>Shojo</option>"
                lugar.innerHTML += "<option value='3'>Seinen</option>"
                lugar.innerHTML += "<option value='4'>Josei</option></ >"
            }
            if (categoria.id == 3) {
                lugar.innerHTML +=
                    "<select id = 'box_categoria' name = 'fruits'>"
                lugar.innerHTML += "<option value='1'>Shonen</option>"
                lugar.innerHTML += "<option value='2'>Shojo</option>"
                lugar.innerHTML += "<option value='3' selected>Seinen</option>"
                lugar.innerHTML += "<option value='4'>Josei</option></ >"
            }
            if (categoria.id == 4) {
                lugar.innerHTML +=
                    "<select id = 'box_categoria' name = 'fruits'>"
                lugar.innerHTML += "<option value='1'>Shonen</option>"
                lugar.innerHTML += "<option value='2'>Shojo</option>"
                lugar.innerHTML += "<option value='3'>Seinen</option>"
                lugar.innerHTML += "<option value='4' selected>Josei</option></ >"
            }

        }
        function alterar() {
            const id = document.getElementById('box_id').value;
            const titulo = document.getElementById('box_titulo').value;
            const autor = document.getElementById('box_autor').value;
            const genero = document.getElementById('box_genero').value;
            const ano_publicacao = document.getElementById('box_ano_publicacao').value;
            const descricao = document.getElementById('box_descricao').value;
            const preco = document.getElementById('box_preco').value;
            const quantidade_em_estoque = document.getElementById('box_quantidade_em_estoque').value;
            const editora = document.getElementById('box_editora').value;
            let categoria = document.getElementById('box_categoria').value;
            if (categoria == "1") {
                categoria = "Shonen"
            }
            if (categoria == "2") {

                categoria = "Shojo"
            }
            if (categoria == "3") {

                categoria = "Seinen"
            }
            if (categoria == "4") {
                categoria = "Josei"
            }
            console.log(categoria)
            httpClient.put('http://localhost/mangas/' + id, {
                titulo: titulo,
                autor: autor,
                genero: genero,
                ano_publicacao: ano_publicacao,
                descricao: descricao,
                preco: preco,
                quantidade_em_estoque: quantidade_em_estoque,
                editora: editora,
                categoria: categoria,
            }).then(data => {
                console.log(data);
            });
            alert('alterado')
            window.location = "http://localhost/tela/admin/mangas";
        }
    </script>

    <?php
    include_once (__DIR__ . '\..\scripts\bootstrap.php');
    ?>

</body>

</html>