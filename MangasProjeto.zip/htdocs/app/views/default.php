<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <?php
    include_once (__DIR__ . '\css\bootstrap.php');
    ?>
</head>

<body>
    <?php
    include_once (__DIR__ . '\components\menu.php');
    ?>


    <?php
    include_once (__DIR__ . '\scripts\bootstrap.php');
    ?>
</body>

</html>