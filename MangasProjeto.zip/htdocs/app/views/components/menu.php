<?php
@$logado = $_SESSION['logado'];
@$usuarioADM = $_SESSION['admin'];
@$usuario = $_SESSION['usuario'];
@$saldo = $_SESSION['saldo'];

$textoUser = $usuarioADM ? "ADMINISTRADOR":"USUARIO COMUM";
$sair = $logado != null ? ' <li class="nav-item">
        <a class="btn btn-danger" href="/sair">Sair</a>
      </li>' : '';
$usuarioInfos = $logado ? "<li class='nav-item fs-4'> USUARIO: ".$usuario." | SALDO: ". $saldo . " | ".  $textoUser ."</li>" : "";
echo '<nav class="navbar navbar-expand-lg bg-body-tertiary">
<div class="container-fluid">
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="/">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/tela/mangas">Mangas</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="#">Carrinho</a>
      </li>'
      . (!$logado? 
      '<li class="nav-item"><a class="nav-link disabled" aria-disabled="true">Admin</a></li>' : 
      '<li class="nav-item"><a class="nav-link" href="/tela/admin">Admin</a></li>').$sair. $usuarioInfos .
      '
      
    </ul>
  </div>
</div>
</nav>';