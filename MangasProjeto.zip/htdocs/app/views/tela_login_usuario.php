<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <?php
    include_once (__DIR__ . '\css\bootstrap.php');
    ?>
</head>

<body>
    <?php
    include_once (__DIR__ . '\components\menu.php');
    ?>
    <div class="container">
        <h1>Login</h1>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" aria-describedby="emailHelp" value="zatch73@duck.com">
            </div>
            <div class="mb-3">
                <label for="senha" class="form-label">Senha</label>
                <input type="password" class="form-control" id="senha" value="1234">
            </div>
            <div class="mb-3">
                <a href="/tela/cadastro">Não tem uma conta? Entre aqui!</a>
            </div>
            <button type="submit" class="btn btn-primary" onclick="fazerLogin()">Entrar</button>
    </div>

    <?php
    include_once (__DIR__ . '\scripts\bootstrap.php');
    ?>
    <script src="./js/http.js"></script>
    <script>
        const httpClient = new HttpClient();
        async function fazerLogin(){
            const email = document.getElementById('email').value;
            const senha = document.getElementById('senha').value;
            const response = await httpClient.post('http://localhost/login', {
                email: email,
                senha: senha
            })

            alert(response.status);
            window.location = "/";
        }
    </script>
</body>

</html>