<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

  <title></title>

  <?php
  include_once (__DIR__ . '\css\bootstrap.php');
  ?>

</head>

<body>

  <?php
  include_once (__DIR__ . '\components\menu.php');
  ?>

  <table class="table container">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Titulo</th>
        <th scope="col">Autor</th>
        <th scope="col">Genero</th>
        <th scope="col">Ano Publicacao</th>
        <th scope="col">Descricao</th>
        <th scope="col">Preco</th>
        <th scope="col">Quantidades</th>
        <th scope="col">Editora</th>
        <th scope="col">Acoes</th>
      </tr>
    </thead>
    <tbody id="mangas_box">

    </tbody>
  </table>

  <script src="./js/http.js"></script>
  <script>
    const httpClient = new HttpClient();
    let mangas = null;
    var resultado = httpClient.get('http://localhost/mangas').then((data) => {
      mangas = data;
      let lista_de_mangas = "";
      for (let i = 0; i < data.length; i++) {
        let manga = criarEstruturaManga(mangas[i]);
        lista_de_mangas += manga;
      }
      const mangasBox = document.getElementById('mangas_box');
      mangasBox.innerHTML = lista_de_mangas;

    })

    function criarEstruturaManga(manga) {
      return `<tr>
      <th>${manga.id}</th>
      <td>${manga.titulo}</td>
      <td>${manga.autor}</td>
      <td>${manga.genero}</td>
      <td>${manga.ano_publicacao}</td>
      <td>${manga.descricao}</td>
      <td>${manga.preco}</td>
      <td>${manga.quantidade_em_estoque}</td>
      <td>${manga.editora}</td>
      <td>
        <button class='btn btn-primary'>
          <i class='fas fa-plus'></i>
        </button>
        <button class='btn btn-danger'>
          <i class='fas fa-minus'></i>
        </button>
        </td>
      </tr>`;
    }

  </script>
  <?php
  include_once (__DIR__ . '\scripts\bootstrap.php');
  ?>

</body>

</html>